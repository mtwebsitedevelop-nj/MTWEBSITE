# MTECH Website (Manchester Technology LLC) - Designer Handoff

Build v22 (development stage). Static HTML/CSS/JS site, no build step.

## How to view it
Open `index.html` in a browser, or upload the whole folder to any static host
(GitHub Pages, Netlify, Apache). Dev link: https://mtwebsitedevelop-nj.github.io/MTWEBSITE/

## Structure
- `index.html`      Public home page
- `admin.html`      Admin console (separate page, hidden from search in robots.txt)
- `app.js`          All site logic and content rendering (shared by every page)
- `styles.css`      Site styles
- `images/`         Logos, banners, "Our Expertise" images (compressed WebP/PNG)
- `og-image.jpg`    Social share image
- `about/ contact/ faqs/ expertise/ products/ sales/ service/`  Main pages
- `brand-*/ epson-*/ canon-*/ papercut-*/ sales/*`  One folder per brand,
  product and sales page (each is its own Google-indexable URL)
- `sitemap.xml`, `robots.txt`, `404.html`, `.htaccess`, `_redirects`  SEO / hosting
- `supabase-setup.sql`  Database tables for admin-managed products and leads

## Brand and design rules
- Colours follow the logo: red and navy.
- EPSON is always written in upper case, in colour #10218B.
- Brands: EPSON, Canon, Kyocera, Toshiba (labels), PaperCut, HP.
- English only. Must work on mobile, tablet and desktop.
- Images must be high quality but small in file size.

## Notes for the designers
- Each page folder holds an `index.html` that loads `../app.js` (path depth varies).
  Edit shared look in `styles.css`; page content is rendered from `app.js`.
- Product data, logos, slides and the chat greeting are edited in the admin
  console and stored in Supabase, so they will not appear in the HTML files.
- Admin login security and server-side hardening are deferred until launch.

## Contact details used on the site
Head office: Office 401, Mohd Al Mulla Tower, Al Wahda Street, Sharjah, P.O. Box 39898
Branch: 18 Street 14 Sector M38, Musaffah, Abu Dhabi
Phone +971 (06) 5455553 | sales@ / helpdesk@manchestertech.ae

## v22 additions: Areas and Blog
- Area pages (16): /printer-rental-{sharjah,dubai,abu-dhabi,ajman,rak,fujairah,al-ain}/, /photocopier-rental-{sharjah,dubai,abu-dhabi}/, /printer-repair-{...}/, /printer-amc-{...}/, plus the index /areas/.
- Blog: /blog/ (filter by Rental & Lease, Service & AMC, Products & Buying Guides) and /blog/<post>/ (6 starter articles).
- Admin console: new tabs "Area pages" and "Blog" (add, edit, reorder, hide, delete; blog pictures). Saved to Supabase keys `areas` and `blog`.
- Home page: new "Areas We Serve" section. Nav: Areas and Blog added. Sitemap updated.
- Rule: no prices or amounts anywhere on the site.
